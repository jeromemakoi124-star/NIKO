#!/data/data/com.termux/files/usr/bin/bash
# AI Voice Assistant - Android Termux Installer
# Install Termux from F-Droid first: https://f-droid.org

echo ""
echo "============================================"
echo "  AI Voice Assistant - Android (Termux)"
echo "============================================"
echo ""

# Update Termux
pkg update -y && pkg upgrade -y

# Install core packages
echo "[INSTALL] Installing packages..."
pkg install -y python python-pip portaudio \
    termux-api espeak 2>/dev/null || true

# Python packages
echo "[INSTALL] Installing Python packages..."
pip install SpeechRecognition pyttsx3 requests \
    pillow --quiet 2>/dev/null || true

# Termux permissions needed
echo ""
echo "[PERMISSIONS] Requesting Termux permissions..."
echo "Please allow microphone, camera, and storage when prompted."
termux-microphone-record -h >/dev/null 2>&1 || true
termux-camera-photo -h    >/dev/null 2>&1 || true

# Storage access
termux-setup-storage 2>/dev/null || true

# Create launch script
cat > "$HOME/start_assistant.sh" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/voice_assistant"
python assistant.py
EOF
chmod +x "$HOME/start_assistant.sh"

echo ""
echo "============================================"
echo "  SETUP COMPLETE!"
echo ""
echo "  Steps:"
echo "  1. Edit ~/.voice_assistant_config.json"
echo "     add your Anthropic API key"
echo ""
echo "  2. Run: bash ~/start_assistant.sh"
echo ""
echo "  NOTES for Android:"
echo "  - Voice: uses termux-tts-speak"
echo "  - Camera: uses termux-camera-photo"
echo "  - Mic: uses termux-microphone-record"
echo "  - Install Termux:API app from F-Droid!"
echo "============================================"
