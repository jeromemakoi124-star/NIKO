#!/usr/bin/env bash
set -e

echo ""
echo "============================================"
echo "  AI Voice Assistant - Linux/Ubuntu Setup"
echo "============================================"
echo ""

# Detect distro
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
else
    DISTRO="unknown"
fi
echo "[INFO] Distro: $DISTRO"

# Install system deps
echo "[INSTALL] Installing system packages..."
if command -v apt-get &>/dev/null; then
    sudo apt-get update -qq
    sudo apt-get install -y python3 python3-pip python3-dev \
        portaudio19-dev espeak espeak-ng \
        python3-tk scrot xdotool fswebcam \
        libasound2-dev libpulse-dev \
        libgl1-mesa-glx 2>/dev/null || true
elif command -v dnf &>/dev/null; then
    sudo dnf install -y python3 python3-pip portaudio-devel espeak \
        python3-tkinter scrot xdotool 2>/dev/null || true
elif command -v pacman &>/dev/null; then
    sudo pacman -Sy --noconfirm python python-pip portaudio espeak \
        scrot xdotool 2>/dev/null || true
fi

echo "[OK] System packages installed."

# Python packages
echo ""
echo "[INSTALL] Installing Python packages..."
pip3 install SpeechRecognition pyttsx3 pyaudio pyautogui \
    psutil pillow requests opencv-python-headless \
    --break-system-packages --quiet 2>/dev/null || \
pip3 install SpeechRecognition pyttsx3 pyaudio pyautogui \
    psutil pillow requests opencv-python-headless --quiet 2>/dev/null || true

echo "[OK] Python packages installed."

# Create desktop launcher
DESKTOP_FILE="$HOME/.local/share/applications/voice-assistant.desktop"
mkdir -p "$HOME/.local/share/applications"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=AI Voice Assistant
Comment=Claude-powered voice control
Exec=python3 $SCRIPT_DIR/assistant.py
Icon=audio-input-microphone
Terminal=true
Categories=Utility;Accessibility;
EOF
chmod +x "$DESKTOP_FILE"
echo "[OK] Desktop launcher created."

# Create init config
python3 -c "
import json, pathlib, platform
cfg = {
    'anthropic_api_key': 'YOUR_ANTHROPIC_API_KEY_HERE',
    'wake_word': 'assistant',
    'language': 'en-US',
    'voice_speed': 175,
    'voice_volume': 1.0,
    'screenshot_dir': str(pathlib.Path.home() / 'Pictures'),
    'documents_dir': str(pathlib.Path.home() / 'Documents'),
    'enable_webcam': True,
    'enable_screenshot': True,
    'enable_file_ops': True,
    'enable_browser': True,
    'enable_app_launch': True,
    'model': 'claude-sonnet-4-6',
}
p = pathlib.Path.home() / '.voice_assistant_config.json'
if not p.exists():
    p.write_text(json.dumps(cfg, indent=2))
    print(f'Config created at {p}')
else:
    print(f'Config already exists at {p}')
"

echo ""
echo "============================================"
echo "  SETUP COMPLETE!"
echo ""
echo "  Next steps:"
echo "  1. Edit ~/.voice_assistant_config.json"
echo "     and add your Anthropic API key"
echo "     Get one at: https://console.anthropic.com"
echo ""
echo "  2. Run the assistant:"
echo "     python3 $SCRIPT_DIR/assistant.py"
echo ""
echo "  OR open the browser UI:"
echo "     $SCRIPT_DIR/ui/launcher.html"
echo "============================================"
echo ""
