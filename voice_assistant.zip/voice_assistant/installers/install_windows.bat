@echo off
title AI Voice Assistant - Windows Installer
color 0A
echo.
echo  ============================================
echo   AI Voice Assistant - Windows Setup
echo  ============================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Downloading installer...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe' -OutFile '%TEMP%\python_installer.exe'"
    start /wait %TEMP%\python_installer.exe /quiet InstallAllUsers=1 PrependPath=1
    echo [OK] Python installed. Please re-run this script.
    pause
    exit /b
)

echo [OK] Python found.

:: Install pip packages
echo.
echo [INSTALL] Installing required packages...
pip install SpeechRecognition pyttsx3 pyautogui psutil pillow requests --quiet
pip install pyaudio --quiet 2>nul || (
    echo [INFO] PyAudio needs extra step on Windows...
    pip install pipwin --quiet
    pipwin install pyaudio --quiet 2>nul
)

echo.
echo [OK] Packages installed.

:: Create desktop shortcut
echo [SETUP] Creating desktop shortcut...
set SCRIPT_DIR=%~dp0
set SHORTCUT=%USERPROFILE%\Desktop\Voice Assistant.lnk
powershell -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath='python'; $s.Arguments='"%SCRIPT_DIR%assistant.py"'; $s.WorkingDirectory='%SCRIPT_DIR%'; $s.IconLocation='%SystemRoot%\System32\shell32.dll,14'; $s.Save()"
echo [OK] Shortcut created on Desktop.

:: Open config for API key setup
echo.
echo [CONFIG] Opening config file for API key...
if not exist "%USERPROFILE%\.voice_assistant_config.json" (
    python -c "import json,pathlib; p=pathlib.Path.home()/'.voice_assistant_config.json'; p.write_text(json.dumps({'anthropic_api_key':'YOUR_ANTHROPIC_API_KEY_HERE','wake_word':'assistant','language':'en-US','voice_speed':180,'voice_volume':1.0,'screenshot_dir':str(pathlib.Path.home()/'Pictures'),'documents_dir':str(pathlib.Path.home()/'Documents'),'enable_webcam':True,'enable_screenshot':True,'enable_file_ops':True,'enable_browser':True,'enable_app_launch':True,'model':'claude-sonnet-4-6'},indent=2))"
)
notepad "%USERPROFILE%\.voice_assistant_config.json"

echo.
echo  ============================================
echo   SETUP COMPLETE!
echo   1. Add your Anthropic API key to the
echo      config file that just opened
echo   2. Double-click "Voice Assistant" on Desktop
echo      OR open launcher.html in your browser
echo  ============================================
echo.
pause
