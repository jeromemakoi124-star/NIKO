"""
Universal AI Voice Assistant - powered by Claude
Cross-platform: Windows, Linux, macOS, Android (Termux)
"""

import os
import sys
import json
import time
import platform
import subprocess
import threading
import queue
import base64
import re
import urllib.request
import urllib.error
import http.client
from datetime import datetime
from pathlib import Path

# ─── Platform Detection ───────────────────────────────────────────────────────
PLATFORM = platform.system()  # 'Windows', 'Linux', 'Darwin'
IS_ANDROID = "ANDROID_ROOT" in os.environ or os.path.exists("/system/app")
IS_TERMUX  = os.path.exists("/data/data/com.termux")

print(f"[SYSTEM] Platform: {PLATFORM} | Android: {IS_ANDROID} | Termux: {IS_TERMUX}")

# ─── Lazy Imports (graceful fallback) ─────────────────────────────────────────
def try_import(name, pip_name=None):
    try:
        return __import__(name)
    except ImportError:
        return None

sr        = try_import("speech_recognition")
pyttsx3   = try_import("pyttsx3")
pyautogui = try_import("pyautogui")
psutil    = try_import("psutil")
cv2       = try_import("cv2")
PIL_Image = None
try:
    from PIL import Image
    PIL_Image = Image
except ImportError:
    pass

# ─── Config ───────────────────────────────────────────────────────────────────
CONFIG_PATH = Path.home() / ".voice_assistant_config.json"

DEFAULT_CONFIG = {
    "anthropic_api_key": "YOUR_ANTHROPIC_API_KEY_HERE",
    "wake_word": "assistant",
    "language": "en-US",
    "voice_speed": 180,
    "voice_volume": 1.0,
    "screenshot_dir": str(Path.home() / "Screenshots"),
    "documents_dir": str(Path.home() / "Documents"),
    "enable_webcam": True,
    "enable_screenshot": True,
    "enable_file_ops": True,
    "enable_browser": True,
    "enable_app_launch": True,
    "model": "claude-sonnet-4-6",
}

def load_config():
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
        # merge with defaults for any missing keys
        for k, v in DEFAULT_CONFIG.items():
            cfg.setdefault(k, v)
        return cfg
    else:
        with open(CONFIG_PATH, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        print(f"[CONFIG] Created config at {CONFIG_PATH}")
        print("[CONFIG] Please add your Anthropic API key to the config file!")
        return DEFAULT_CONFIG.copy()

CONFIG = load_config()

# ─── Text-to-Speech ───────────────────────────────────────────────────────────
class Speaker:
    def __init__(self):
        self.engine = None
        self._init_engine()

    def _init_engine(self):
        if pyttsx3:
            try:
                self.engine = pyttsx3.init()
                self.engine.setProperty("rate",   CONFIG["voice_speed"])
                self.engine.setProperty("volume", CONFIG["voice_volume"])
                # Try to pick a good voice
                voices = self.engine.getProperty("voices")
                if voices:
                    # Prefer a female/natural voice if available
                    for v in voices:
                        if any(x in v.name.lower() for x in ["zira", "female", "natural", "samantha"]):
                            self.engine.setProperty("voice", v.id)
                            break
            except Exception as e:
                print(f"[TTS] pyttsx3 error: {e}")
                self.engine = None

    def say(self, text):
        print(f"[ASSISTANT] {text}")
        if self.engine:
            try:
                self.engine.say(text)
                self.engine.runAndWait()
                return
            except Exception:
                pass
        # Fallback: OS-level TTS
        self._os_speak(text)

    def _os_speak(self, text):
        text = text.replace('"', '')
        if PLATFORM == "Windows":
            subprocess.Popen(
                ["powershell", "-Command",
                 f'Add-Type -AssemblyName System.Speech; '
                 f'$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; '
                 f'$s.Speak("{text}")'],
                creationflags=subprocess.CREATE_NO_WINDOW
            ).wait()
        elif PLATFORM == "Darwin":
            subprocess.run(["say", text], check=False)
        elif IS_TERMUX:
            subprocess.run(["termux-tts-speak", text], check=False)
        else:
            for cmd in [["espeak", text], ["festival", "--tts"], ["spd-say", text]]:
                if subprocess.run(["which", cmd[0]], capture_output=True).returncode == 0:
                    subprocess.run(cmd if len(cmd) == 2 else cmd[:1] + [text], check=False)
                    break

speaker = Speaker()

# ─── Speech-to-Text ──────────────────────────────────────────────────────────
class Listener:
    def __init__(self):
        self.recognizer = sr.Recognizer() if sr else None
        self.mic = None
        if sr:
            try:
                self.mic = sr.Microphone()
                # Calibrate for ambient noise
                with self.mic as source:
                    self.recognizer.adjust_for_ambient_noise(source, duration=1)
                print("[MIC] Microphone ready")
            except Exception as e:
                print(f"[MIC] No microphone found: {e}")
                self.mic = None

    def listen_once(self, timeout=10, phrase_limit=15):
        """Listen for a single voice command."""
        if not self.mic or not self.recognizer:
            return self._text_fallback()
        try:
            with self.mic as source:
                print("[LISTENING] Speak now...")
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_limit)
            # Try Google (online) first, fall back to Sphinx (offline)
            try:
                text = self.recognizer.recognize_google(audio, language=CONFIG["language"])
                print(f"[HEARD] {text}")
                return text.lower()
            except Exception:
                pass
            try:
                text = self.recognizer.recognize_sphinx(audio)
                print(f"[HEARD-OFFLINE] {text}")
                return text.lower()
            except Exception:
                return None
        except Exception as e:
            print(f"[LISTEN ERROR] {e}")
            return None

    def _text_fallback(self):
        """Keyboard input when no mic is available."""
        try:
            return input("[TYPE COMMAND] > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return "quit"

listener = Listener()

# ─── Claude API ───────────────────────────────────────────────────────────────
class ClaudeAI:
    def __init__(self):
        self.api_key  = CONFIG["anthropic_api_key"]
        self.model    = CONFIG["model"]
        self.history  = []  # conversation memory
        self.sys_prompt = self._build_system_prompt()

    def _build_system_prompt(self):
        return f"""You are a powerful AI voice assistant running on {PLATFORM}.
You control the user's computer through voice commands.

Current date/time: {datetime.now().strftime('%Y-%m-%d %H:%M')}
Platform: {PLATFORM} | Android: {IS_ANDROID}

Your job is to:
1. Understand natural voice commands
2. Respond with BOTH a spoken response AND structured actions

ALWAYS respond in this JSON format:
{{
  "speak": "What you say to the user (keep concise, friendly)",
  "actions": [
    {{"type": "ACTION_TYPE", "params": {{...}}}}
  ],
  "followup": "optional question to ask user"
}}

Available ACTION TYPES:
- open_app: {{"name": "chrome|firefox|notepad|word|excel|photoshop|autocad|metatrader5|vlc|..."}}
- type_text: {{"text": "text to type", "press_enter": true/false}}
- key_press: {{"keys": "ctrl+c or alt+tab or win+d ..."}}
- open_url: {{"url": "https://..."}}
- screenshot: {{"filename": "optional_name.png"}}
- webcam_photo: {{"filename": "photo.jpg"}}
- run_command: {{"cmd": "shell command", "shell": true}}
- write_file: {{"path": "filepath", "content": "file content"}}
- read_file: {{"path": "filepath"}}
- search_web: {{"query": "search terms"}}
- send_email: {{"to": "email", "subject": "subj", "body": "body"}}
- math: {{"expression": "2+2*sqrt(16)"}}
- reminder: {{"text": "reminder", "minutes": 5}}
- speak_only: {{}}  (just talk, no computer action)

IMPORTANT RULES:
- For WhatsApp: open web.whatsapp.com in browser, then type message
- For emails: use mailto: links or compose via Gmail/Outlook web
- For documents: open Word/LibreOffice and type_text  
- For photos: use webcam_photo action
- For calculations: use math action and speak the result
- Always be brief in "speak" — this is read aloud
- Never include markdown in "speak" field
- If unsure of an app path, try open_app and fall back gracefully
"""

    def ask(self, user_input, extra_context=""):
        """Send a message to Claude and get structured response."""
        self.history.append({"role": "user", "content": user_input + (f"\n[CONTEXT: {extra_context}]" if extra_context else "")})
        # Keep last 20 turns to save tokens
        history_trimmed = self.history[-20:]

        payload = json.dumps({
            "model":      self.model,
            "max_tokens": 1024,
            "system":     self.sys_prompt,
            "messages":   history_trimmed,
        }).encode("utf-8")

        try:
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=payload,
                headers={
                    "Content-Type":      "application/json",
                    "x-api-key":         self.api_key,
                    "anthropic-version": "2023-06-01",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read())

            raw = data["content"][0]["text"]
            self.history.append({"role": "assistant", "content": raw})

            # Parse JSON response
            # Strip markdown fences if present
            raw = re.sub(r"```json\s*|\s*```", "", raw).strip()
            return json.loads(raw)

        except urllib.error.HTTPError as e:
            body = e.read().decode()
            print(f"[API ERROR] {e.code}: {body}")
            if e.code == 401:
                return {"speak": "API key is invalid. Please update your config file.", "actions": []}
            return {"speak": f"API error {e.code}. Please check your connection.", "actions": []}
        except Exception as e:
            print(f"[AI ERROR] {e}")
            return {"speak": "I had trouble connecting. Please check your internet.", "actions": []}

ai = ClaudeAI()

# ─── Action Executor ──────────────────────────────────────────────────────────
class ActionRunner:

    def run(self, action):
        atype  = action.get("type", "")
        params = action.get("params", {})
        handler = getattr(self, f"do_{atype}", self.unknown)
        try:
            return handler(params)
        except Exception as e:
            print(f"[ACTION ERROR] {atype}: {e}")
            return f"Error during {atype}: {e}"

    def unknown(self, params):
        print(f"[ACTION] Unknown action: {params}")

    # ── App launching ──────────────────────────────────────────────────────────
    def do_open_app(self, p):
        name = p.get("name", "").lower()
        print(f"[ACTION] Opening app: {name}")

        # App name → command mapping per platform
        app_map = {
            "windows": {
                "chrome":       "start chrome",
                "firefox":      "start firefox",
                "edge":         "start msedge",
                "notepad":      "notepad",
                "word":         "start winword",
                "excel":        "start excel",
                "powerpoint":   "start powerpnt",
                "outlook":      "start outlook",
                "teams":        "start teams",
                "calculator":   "calc",
                "paint":        "mspaint",
                "explorer":     "explorer",
                "cmd":          "start cmd",
                "powershell":   "start powershell",
                "task manager": "taskmgr",
                "vlc":          "start vlc",
                "photoshop":    "start photoshop",
                "autocad":      "start acad",
                "archicad":     "start archicad",
                "metatrader5":  "start terminal64",
                "metatrader 5": "start terminal64",
                "whatsapp":     "start whatsapp",
                "telegram":     "start telegram",
                "zoom":         "start zoom",
                "skype":        "start skype",
                "spotify":      "start spotify",
                "discord":      "start discord",
            },
            "linux": {
                "chrome":       "google-chrome",
                "firefox":      "firefox",
                "libreoffice":  "libreoffice",
                "writer":       "libreoffice --writer",
                "calc":         "libreoffice --calc",
                "impress":      "libreoffice --impress",
                "gedit":        "gedit",
                "nautilus":     "nautilus",
                "vlc":          "vlc",
                "gimp":         "gimp",
                "inkscape":     "inkscape",
                "terminal":     "x-terminal-emulator",
                "calculator":   "gnome-calculator",
                "metatrader5":  "wine terminal64.exe",
                "autocad":      "wine acad.exe",
                "zoom":         "zoom",
                "telegram":     "telegram-desktop",
                "discord":      "discord",
                "spotify":      "spotify",
            },
            "darwin": {
                "chrome":       "open -a 'Google Chrome'",
                "firefox":      "open -a Firefox",
                "safari":       "open -a Safari",
                "word":         "open -a 'Microsoft Word'",
                "excel":        "open -a 'Microsoft Excel'",
                "powerpoint":   "open -a 'Microsoft PowerPoint'",
                "outlook":      "open -a 'Microsoft Outlook'",
                "calculator":   "open -a Calculator",
                "finder":       "open -a Finder",
                "terminal":     "open -a Terminal",
                "vlc":          "open -a VLC",
                "zoom":         "open -a zoom.us",
                "spotify":      "open -a Spotify",
                "discord":      "open -a Discord",
            },
        }

        platform_key = PLATFORM.lower()
        if platform_key not in app_map:
            platform_key = "linux"

        cmd = app_map[platform_key].get(name)
        if cmd:
            subprocess.Popen(cmd, shell=True)
            return f"Opened {name}"
        else:
            # Generic try
            subprocess.Popen(name, shell=True)
            return f"Attempted to open {name}"

    # ── Type text ─────────────────────────────────────────────────────────────
    def do_type_text(self, p):
        text = p.get("text", "")
        enter = p.get("press_enter", False)
        if pyautogui:
            time.sleep(0.5)
            pyautogui.typewrite(text, interval=0.05)
            if enter:
                pyautogui.press("enter")
        else:
            print(f"[TYPE] Would type: {text}")
            if PLATFORM == "Linux":
                subprocess.run(["xdotool", "type", "--delay", "50", text], check=False)
                if enter:
                    subprocess.run(["xdotool", "key", "Return"], check=False)
        return f"Typed: {text}"

    # ── Key press ─────────────────────────────────────────────────────────────
    def do_key_press(self, p):
        keys = p.get("keys", "")
        if pyautogui:
            pyautogui.hotkey(*keys.replace("+", " ").split())
        elif PLATFORM == "Linux":
            subprocess.run(["xdotool", "key", keys.replace("+", "+")])
        return f"Pressed: {keys}"

    # ── Open URL ──────────────────────────────────────────────────────────────
    def do_open_url(self, p):
        url = p.get("url", "")
        import webbrowser
        webbrowser.open(url)
        return f"Opened: {url}"

    # ── Screenshot ────────────────────────────────────────────────────────────
    def do_screenshot(self, p):
        if not CONFIG["enable_screenshot"]:
            return "Screenshots disabled"
        filename = p.get("filename", f"screenshot_{int(time.time())}.png")
        outdir   = Path(CONFIG["screenshot_dir"])
        outdir.mkdir(parents=True, exist_ok=True)
        path = str(outdir / filename)

        if pyautogui:
            img = pyautogui.screenshot()
            img.save(path)
        elif PIL_Image:
            # Try scrot/gnome-screenshot on Linux
            subprocess.run(["scrot", path], check=False)
        elif PLATFORM == "Windows":
            subprocess.run(["powershell", "-command",
                f"Add-Type -AssemblyName System.Windows.Forms; "
                f"[System.Windows.Forms.Screen]::PrimaryScreen | Out-Null; "
                f"$bmp=New-Object System.Drawing.Bitmap([System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width,"
                f"[System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height);"
                f"$g=[System.Drawing.Graphics]::FromImage($bmp);"
                f"$g.CopyFromScreen(0,0,0,0,$bmp.Size);"
                f"$bmp.Save('{path}')"], check=False)
        elif IS_TERMUX:
            subprocess.run(["termux-screenshot", "-o", path], check=False)
        print(f"[SCREENSHOT] Saved to {path}")
        return f"Screenshot saved to {path}"

    # ── Webcam photo ──────────────────────────────────────────────────────────
    def do_webcam_photo(self, p):
        if not CONFIG["enable_webcam"]:
            return "Webcam disabled"
        filename = p.get("filename", f"photo_{int(time.time())}.jpg")
        outdir   = Path(CONFIG["screenshot_dir"])
        outdir.mkdir(parents=True, exist_ok=True)
        path = str(outdir / filename)

        if cv2:
            cap = cv2.VideoCapture(0)
            if cap.isOpened():
                time.sleep(0.5)  # warm up
                ret, frame = cap.read()
                cap.release()
                if ret:
                    cv2.imwrite(path, frame)
                    print(f"[WEBCAM] Photo saved: {path}")
                    return f"Photo saved to {path}"
        elif IS_TERMUX:
            subprocess.run(["termux-camera-photo", "-c", "0", path], check=False)
            return f"Photo saved to {path}"
        elif PLATFORM == "Linux":
            subprocess.run(["fswebcam", "-r", "1280x720", path], check=False)
            return f"Photo saved to {path}"
        return "Could not access webcam"

    # ── Run shell command ─────────────────────────────────────────────────────
    def do_run_command(self, p):
        cmd   = p.get("cmd", "")
        shell = p.get("shell", True)
        if not cmd:
            return "No command specified"
        print(f"[CMD] Running: {cmd}")
        try:
            result = subprocess.run(cmd, shell=shell, capture_output=True, text=True, timeout=30)
            return result.stdout or result.stderr or "Done"
        except subprocess.TimeoutExpired:
            return "Command timed out"
        except Exception as e:
            return str(e)

    # ── Write file ────────────────────────────────────────────────────────────
    def do_write_file(self, p):
        if not CONFIG["enable_file_ops"]:
            return "File operations disabled"
        path    = Path(p.get("path", "output.txt"))
        content = p.get("content", "")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        print(f"[FILE] Written: {path}")
        return f"File written: {path}"

    # ── Read file ─────────────────────────────────────────────────────────────
    def do_read_file(self, p):
        if not CONFIG["enable_file_ops"]:
            return "File operations disabled"
        path = Path(p.get("path", ""))
        if path.exists():
            return path.read_text(encoding="utf-8", errors="replace")[:3000]
        return "File not found"

    # ── Web search ────────────────────────────────────────────────────────────
    def do_search_web(self, p):
        query = p.get("query", "")
        import webbrowser
        url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
        webbrowser.open(url)
        return f"Searching for: {query}"

    # ── Send email (via mailto or Gmail) ─────────────────────────────────────
    def do_send_email(self, p):
        to      = p.get("to", "")
        subject = p.get("subject", "")
        body    = p.get("body", "")
        import webbrowser
        # Try mailto first (opens default mail client)
        import urllib.parse
        mailto = f"mailto:{to}?subject={urllib.parse.quote(subject)}&body={urllib.parse.quote(body)}"
        webbrowser.open(mailto)
        return f"Email draft opened for {to}"

    # ── Math ──────────────────────────────────────────────────────────────────
    def do_math(self, p):
        expr = p.get("expression", "")
        try:
            import math
            # Safe eval with math functions available
            safe_dict = {k: getattr(math, k) for k in dir(math) if not k.startswith("_")}
            safe_dict["abs"] = abs
            result = eval(expr, {"__builtins__": {}}, safe_dict)
            return str(result)
        except Exception as e:
            return f"Math error: {e}"

    # ── Reminder ──────────────────────────────────────────────────────────────
    def do_reminder(self, p):
        text    = p.get("text", "Reminder!")
        minutes = int(p.get("minutes", 5))
        def _remind():
            time.sleep(minutes * 60)
            speaker.say(f"Reminder: {text}")
        threading.Thread(target=_remind, daemon=True).start()
        return f"Reminder set for {minutes} minutes"

    def do_speak_only(self, p):
        return "speaking"

runner = ActionRunner()

# ─── Need to import urllib.parse here ─────────────────────────────────────────
import urllib.parse

# ─── Main Loop ────────────────────────────────────────────────────────────────
def main():
    speaker.say(f"Voice assistant ready. Say {CONFIG['wake_word']} or just speak your command.")

    while True:
        try:
            # Listen
            command = listener.listen_once()
            if not command:
                continue

            command = command.strip()
            if not command:
                continue

            # Exit words
            if any(w in command for w in ["quit assistant", "exit assistant", "shutdown assistant", "goodbye assistant"]):
                speaker.say("Goodbye! Shutting down.")
                break

            print(f"\n[COMMAND] {command}")

            # Send to Claude
            response = ai.ask(command)

            # Speak the reply
            speak_text = response.get("speak", "")
            if speak_text:
                speaker.say(speak_text)

            # Execute actions
            actions = response.get("actions", [])
            for action in actions:
                result = runner.run(action)
                if result:
                    print(f"[RESULT] {result}")

            # Handle math results — speak them
            for action in actions:
                if action.get("type") == "math":
                    expr   = action.get("params", {}).get("expression", "")
                    result = runner.do_math(action.get("params", {}))
                    speaker.say(f"The answer is {result}")

            # Follow-up question
            followup = response.get("followup", "")
            if followup:
                speaker.say(followup)

        except KeyboardInterrupt:
            speaker.say("Interrupted. Goodbye!")
            break
        except Exception as e:
            print(f"[MAIN ERROR] {e}")
            continue

if __name__ == "__main__":
    main()
