# 🎙 AI Voice Assistant — Universal Computer Control
### Powered by Claude AI · Works on Windows, Linux, Ubuntu, macOS, Android

---

## What It Does

Control your entire computer with your voice. Just speak naturally and the assistant will:

| Capability | Examples |
|---|---|
| **Launch any app** | "Open Chrome", "Open Excel", "Open MetaTrader 5", "Open AutoCAD" |
| **Web & Email** | "Open WhatsApp Web", "Send email to John", "Search the web for..." |
| **Documents** | "Open Word and write a letter to my client" |
| **Photos** | "Take a photo with my webcam", "Take a screenshot" |
| **Math** | "Calculate 25% of 8500", "What is the square root of 144" |
| **Files** | "Create a file called notes.txt with...", "Read my document" |
| **Reminders** | "Remind me in 15 minutes to call the office" |
| **Trading** | "Open MetaTrader 5" (MT5 must be installed on your PC) |
| **Engineering** | "Open AutoCAD", "Open ArchiCAD" (software must be installed) |

---

## Quick Start

### Option A — Browser UI (Works on ALL devices, easiest)
1. Open `ui/launcher.html` in any browser (Chrome, Firefox, Edge, Safari)
2. Enter your Anthropic API key (get one free at https://console.anthropic.com)
3. Click the 🎙 mic button and start speaking!

### Option B — Python App (Full computer control)
Gives you real keyboard control, real app launching, real file access.

---

## Installation by Platform

### 🪟 Windows
```
Double-click: installers/install_windows.bat
```
Then add your API key when Notepad opens.

Run the assistant:
```
python assistant.py
```

### 🐧 Linux / Ubuntu
```bash
chmod +x installers/install_linux.sh
./installers/install_linux.sh
```
Run:
```bash
python3 assistant.py
```

### 📱 Android (Termux)
1. Install **Termux** from F-Droid: https://f-droid.org
2. Install **Termux:API** from F-Droid (same page)
3. Open Termux and run:
```bash
bash install_android_termux.sh
```
4. Run:
```bash
bash ~/start_assistant.sh
```

### 🍎 macOS
```bash
pip3 install SpeechRecognition pyttsx3 pyautogui psutil pillow requests
python3 assistant.py
```

---

## Configuration

Edit `~/.voice_assistant_config.json`:

```json
{
  "anthropic_api_key": "sk-ant-YOUR-KEY-HERE",
  "wake_word": "assistant",
  "language": "en-US",
  "voice_speed": 180,
  "voice_volume": 1.0,
  "screenshot_dir": "C:/Users/You/Pictures",
  "documents_dir": "C:/Users/You/Documents",
  "enable_webcam": true,
  "enable_screenshot": true,
  "enable_file_ops": true,
  "enable_browser": true,
  "enable_app_launch": true
}
```

Get your free API key at: **https://console.anthropic.com**

---

## Voice Command Examples

```
"Open Microsoft Word"
"Take a photo with my webcam"
"Take a screenshot"
"Search the web for latest news in Uganda"
"Open WhatsApp Web"
"Send email to boss@company.com about the meeting"
"Calculate 15 percent of 250,000"
"Open MetaTrader 5"
"Open AutoCAD"
"Remind me in 30 minutes to take my medication"
"Create a text file called report with today's date"
"Open my Documents folder"
"What time is it?"
"Set a timer for 10 minutes"
```

---

## Supported Applications

The assistant can open any installed application. Built-in shortcuts:

**Office & Productivity**
- Microsoft Word, Excel, PowerPoint, Outlook, Teams
- LibreOffice Writer, Calc, Impress (Linux)

**Browsers**
- Google Chrome, Firefox, Microsoft Edge, Safari

**Design & Engineering**
- Adobe Photoshop, Illustrator, Premiere
- AutoCAD, ArchiCAD
- GIMP, Inkscape (free alternatives)

**Trading**
- MetaTrader 5 (must be installed)

**Communication**
- WhatsApp Web, Telegram, Discord, Zoom, Skype

**Utilities**
- Calculator, Notepad, File Explorer, Terminal, VLC

---

## How It Works

```
You speak → Browser/Mic captures audio → Sent to Claude AI
→ Claude understands intent → Returns structured actions
→ Program executes: opens apps, types text, takes photos, etc.
→ Result spoken back to you
```

---

## Privacy & Security

- Your API key is stored locally on your device only
- Voice is processed by your browser's built-in speech engine or Google Speech API
- Commands are sent to Anthropic's Claude API (same privacy as using Claude.ai)
- No data is stored on any external server

---

## Troubleshooting

**No microphone?** → Use the text input field at the bottom of the browser UI

**App won't open?** → Make sure the application is installed. Say the full name: "Open Microsoft Word" not just "Word"

**No sound output?** → Check your speakers. On Linux install espeak: `sudo apt install espeak`

**API errors?** → Verify your API key at https://console.anthropic.com

**Android camera not working?** → Make sure Termux:API app is installed from F-Droid

---

## File Structure

```
voice_assistant/
├── assistant.py          ← Main Python app (full computer control)
├── ui/
│   └── launcher.html     ← Browser UI (works on any device)
├── installers/
│   ├── install_windows.bat
│   ├── install_linux.sh
│   └── install_android_termux.sh
└── README.md             ← This file
```
